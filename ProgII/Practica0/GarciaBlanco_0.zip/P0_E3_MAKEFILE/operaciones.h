
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   operaciones.h
 * Author: marcos.fernandez.pichel
 *
 * Created on January 16, 2023, 9:56 AM
 */

#ifndef OPERACIONES_H
#define OPERACIONES_H

//int sqrt(int n) ;
double sqrt(double n);
int gcd(int a, int b);

#endif  // OPERACIONES_H

